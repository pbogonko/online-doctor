const getTokens=async ()=>{
    try{
    const res=await fetch('https://dev-8kpvcbobrymrrczb.us.auth0.com/oauth/token',{
        method:'POST',
        headers:{
            "Content-Type":"application/json",
        },
        body:JSON.stringify({
                 "client_id":"86bAqwCXq1UIiBSkUsDMm7Qu9kMJIjhy",
                 "client_secret":"yhudJ1b0qHJTfKpDygBHQlC5lOqrn7o5HR9ckjiVTa94CjfSuLdK7bA4vOD6adlA",
                  "audience":"https://api.onlinedoctor.com",
                  "grant_type":"client_credentials"
        })
    })
    if(!res.ok){
       console.log('network error')
        return
    }
    const data=await res.json()
    console.log(data)
}catch(error){
    console.log('ERROR:'+error.message)
}
}
getTokens()