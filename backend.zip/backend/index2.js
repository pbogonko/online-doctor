import 'dotenv/config'
import { auth,claimEquals,claimIncludes,requiredScopes,claimCheck} from 'express-oauth2-jwt-bearer';
import {createAuth0Api,requiresAuth,claimCheck,claimEquals,claimIncludes} from '@auth0/auth0-express-api'
import express from 'express'

const app = express();

app.use(createAuth0Api())
const port = process.env.PORT || 8080;
app.use(express.json())
const jwtCheck = auth({
  audience: process.env.AUTH0_AUDIENCE,
  issuerBaseURL: process.env.AUTH0_DOMAIN,
  tokenSigningAlg: 'RS256'
});

app.get('/api/public', (req, res) => {
  res.json({
    message: 'Hello from a public endpoint! You don\'t need to be authenticated to see this.',
    timestamp: new Date().toISOString(),
   
  });
});

//protected route
app.get('/api/protected',jwtCheck, (req, res) => {
  res.json({
    message: 'Hello from a protected endpoint! for this, You need to be authenticated to see this.',
    user:req.auth.payload.sub,
    timestamp: new Date().toISOString(),
    payload:req.auth.payload
  });
});
//protected route with required scope
//Scoped routes use requiredScopes() to require specific permissions in the token
app.get('/api/protected/scoped',jwtCheck,requiredScopes("role:admin") ,(req, res) => {
  res.json({
    message: 'Hello from a protected endpoint! for this, You need to be authenticated to see this.',
    user:req.auth.payload.sub,
    timestamp: new Date().toISOString(),
    scope:req.auth.payload.scope,
    payload:req.auth.payload
  });
});
///using  auth0 express api

app.get('/api/protected/auth0express',requiresAuth(), (req, res) => {
  res.json({
    message: 'Hello from a protected endpoint! for this, You need to be authenticated to see this.',
    user:req.auth0.user,
    timestamp: new Date().toISOString(),
    
  });
});
// Requires the "read:messages" scope
app.get('/api/messages', requiresAuth({ scopes: ['read:messages'] }), (req, res) => {
  res.json({ message: ['Hello!', 'World!'] });
});
import { scopesInclude } from '@auth0/auth0-express-api';

// Requires ANY of these scopes
app.get('/api/feed', requiresAuth(), scopesInclude(['read:feed', 'read:admin']), (req, res) => {
  res.json({ feed: [] });
});

// Requires ALL of these scopes
app.get('/api/admin/edit', requiresAuth(), scopesInclude(['read:admin', 'write:admin'], { match: 'all' }), (req, res) => {
  res.json({ message: 'Admin editor access granted.' });
});

// claimEquals — claim must equal an exact value
app.get('/api/admin', requiresAuth(), claimEquals('isAdmin', true), (req, res) => {
  res.json({ message: 'Admin access granted.' });
});

// claimIncludes — array claim must contain all listed values
app.get('/api/editor', requiresAuth(), claimIncludes('roles', ['admin', 'editor']), (req, res) => {
  res.json({ message: 'Editor access granted.' });
});

// claimCheck — custom logic over the decoded token
app.get('/api/premium', requiresAuth(), claimCheck(
  (req, token) => token.tier === 'premium' || token.roles?.includes('admin'),
  { errorMessage: 'Premium tier or admin role required' }
), (req, res) => {
  res.json({ message: 'Premium content access granted.' });
});














app.post("/tokens",async(req,res)=> {
  try {

    const {client_id,client_secret,audience,grant_type,scope}=req.body
    
    const body={client_id,client_secret,audience,grant_type,scope}
      const response = await fetch('https://dev-8kpvcbobrymrrczb.us.auth0.com/oauth/token', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
          return res.json(response);
      }

      const data = await response.json();
      res.json(data)
  } catch (error) {
      console.error('Error fetching token:', error);
  }
});
//custom claims
app.get('/users/:userId',jwtCheck,claimEquals('userId','3456'),(req,res)=>{
  const userId=req.params.userId
  return res.json({message:"user access granted"})

})

//requires a claim to include all specified values
app.get('/api/roles',jwtCheck,claimIncludes('admin','staff','student'),(req,res)=>{

  return res.json({message:"action permitted"})

})

// Custom claim validation logic
app.get('/api/premium',
  jwtCheck,
  claimCheck((claims) => {
    return claims.subscription === 'premium' && claims.verified === true;
  }),
  (req, res) => {
    res.json({ message: 'Premium feature access granted' });
  }
);
// Error handling middleware
app.use((err, req, res, next) => {
  const status = err.status || 500;
  const message = err.message || 'Internal Server Error';


  res.status(status).json({
    error: err.code || 'server_error',
    message: status === 401 ? 'Authentication required' : message,
    // payload:req.auth.payload
  });
});
app.listen(port);

console.log('Running on port ', port);