import { useContext, useState } from "react"
import { userImg } from "../../assets/images"
import MyBooking from "./MyBooking"
import Profile from "./Profile"
import { AuthContext } from "../../context/authContext"
import useFetchData from "../../hooks/useFetchData"
import { BASE_URL } from "../../config"
import Loading from "../../Loader/Loading"
import Error from "../../Error/Error"
function Myaccount() {
//     const {user}=useContext(AuthContext)
    const {dispatch}=useContext(AuthContext)
     const handleLogout=()=>{
        dispatch({type:'LOGOUT'})
     }
     const [tab,setTab]=useState( 'bookings')
     const {data:userData,
        loading,error
        }=useFetchData(`${BASE_URL}/users/profile/me`)
     console.log(userData)
   
    
  return(
  <section>
     <div className="max-w-[1170px] px-5 max-auto">

        {
            loading && !error &&<Loading/>

        }
        {!loading && error && <Error errMessage={error}/>}
        {
            !loading && !error &&   (
                <div className="grid md:grid-cols-3 gap-10">
                <div className="pb-[50px] px-[30px] rounded-md">
                    <div className="flex items-center justify-center">
                        <figure className="w-[100px] h-[100px]rounded-full border-2 border-solid border-primaryColor">
                            <img
                             src={userData?.photo||userImg} alt="" className="w-full h-full rounded-full" />
                        </figure>
                    </div>
                    <div className="text-center mt-4">
                        <h3 className="text-[18px] leading-[30px text-headingColor font-bold" >{userData?.name}</h3>
                        <p className="text-textColor text-[15px] leading-6 font-medium">{userData?.email}</p>
                        <p className="text-textColor text-[15px] leading-6 font-medium">
                            Blood Type:
                            <span className="ml-2 text -headingColor text-[22px] lleading-8">{userData?.bloodType}</span>
                        </p>
                    </div>
                    <div className="mt-[50px] md:mt-[100px]">
                        <button onClick={handleLogout} className="w-full bg-[#181A1E] p-3 text-[16px] leading-7 rounded-md text-white">Logout</button>
                        <button className="w-full bg-red-600 mt-4 p-3 text-[16px] leading-7 rounded-md text-white">Delete Account</button>
                    </div>
                     
                </div>
                <div className="md:col-span-2 md:px-[30px]"
                >
                    <div>
                     <button onClick={()=>setTab('bookings')} className={`${tab==='bookings' &&'bg-primaryColor  text-white font-normal' } p-2 mr-5 rounded-md text-headingColor font-semibold text-[16px] leading-border border border-primaryColor`}>My booking</button>
                   <button onClick={()=>setTab('settings')} className={`  ${tab==='settings' && 'bg-primaryColor  text-white font-normal'} py-2 px-5 rounded-md text-headingColor font-semibold text-[16px] leading-border border border-primaryColor`}>profile settings</button>
                   {
                    tab==='bookings' && <MyBooking/>
        
                }
                {
                    tab==='settings' && <Profile user={userData}/>
                }
                </div>
                  
              
        
        
                </div>
               
            </div>
            )
        }

  </div> 
  </section>
  )
}

export default Myaccount