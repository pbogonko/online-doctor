/* eslint-disable react/prop-types */
import { createContext, useEffect, useReducer } from "react";

const initialState = {
    user: localStorage.getItem('user')!==undefined? JSON.parse(localStorage.getItem('user')):null,
    role:localStorage.getItem('role')|| null,
    token:localStorage.getItem('token')|| null

};
 export const AuthContext = createContext(initialState)
 const authReducer = (state, action) => {
    switch (action.type) {
        case 'LOGIN_START':
            return {
                 user: null,
                role: null, 
                token: null
            }  ;
        case 'LOGIN_SUCCESS':
            return {
                user: action.payload.user,
                token: action.payload.token,
                role: action.payload.role 


            };
        case 'LOGOUT':
            return {
                user: null,
                token: null,
                role: null

 
            };

        default:
            return state;
    }
}

export const AutContextProvider = ({ children }) => {
    const [ state, dispatch ] = useReducer(authReducer, initialState);
    useEffect(()=>{
        localStorage.setItem('user',JSON.stringify(state.user))
        localStorage.setItem('token',state.token)
        localStorage.setItem('role',state.role)
    },[state])

    return(
     <AuthContext.Provider value={{
        user:state.user,
        token:state.token,
        role:state.role,
        dispatch
     }}>  
        {children}
        

    </AuthContext.Provider>
    );
};