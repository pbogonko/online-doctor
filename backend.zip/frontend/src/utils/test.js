const x=20;
const navLinks = [
  {
    path: "/home",
    display: "Home",
  },
  {
    path: "/doctors",
    display: "Find a Doctor",
  },
  {
    path: "/services",
    display: "Services",
  },
  {
    path: "/contacts",
    display: "Contact",
  },
];
navLinks.map((links)=>{
    if (x===20&&links.path==='/doctors'){
        links.path="/students"
    }
    console.log(links)
})
